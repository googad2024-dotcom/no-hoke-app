<?php

declare(strict_types=1);

namespace App\Application\Actions\Diagnosis;

use App\Application\Services\DiagnosisScorer;
use App\Models\DiagnosisSession;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;

class SubmitDiagnosisAction
{
    private LoggerInterface $logger;
    private DiagnosisScorer $scorer;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
        $this->scorer = new DiagnosisScorer();
    }

    public function __invoke(Request $request, Response $response): Response
    {
        try {
            $data = $request->getParsedBody();

            if (empty($data['session_id'])) {
                $error = ['success' => false, 'message' => 'Session ID is required'];
                $response->getBody()->write(json_encode($error));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
            }

            $session = DiagnosisSession::where('session_id', $data['session_id'])->first();

            if (!$session) {
                $error = ['success' => false, 'message' => 'Session not found'];
                $response->getBody()->write(json_encode($error));
                return $response->withHeader('Content-Type', 'application/json')->withStatus(404);
            }

            $session->update([
                'age'                => $data['age']                ?? null,
                'has_children'       => $data['has_children']       ?? null,
                'monthly_income'     => $data['monthly_income']     ?? null,
                'monthly_fixed_cost' => $data['monthly_fixed_cost'] ?? null,
                'savings'            => $data['savings']            ?? null,
                'monthly_insurance'  => $data['monthly_insurance']  ?? null,
            ]);

            $diagnosis = $this->scorer->calculate($session);

            $session->diagnosis_score = $diagnosis['score'];
            $session->save();

            $this->logger->info('Diagnosis submitted', [
                'session_id' => $data['session_id'],
                'score'      => $diagnosis['score'],
                'grade'      => $diagnosis['grade'],
            ]);

            $result = [
                'success'       => true,
                'session_id'    => $data['session_id'],
                'score'         => $diagnosis['score'],
                'grade'         => $diagnosis['grade'],
                'grade_message' => $diagnosis['grade_message'],
                'breakdown'     => $diagnosis['breakdown'],
                'message'       => 'Diagnosis submitted successfully',
            ];

            $response->getBody()->write(json_encode($result));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(200);

        } catch (\Exception $e) {
            $this->logger->error('Failed to submit diagnosis', ['error' => $e->getMessage()]);

            $error = ['success' => false, 'message' => 'Failed to submit diagnosis'];
            $response->getBody()->write(json_encode($error));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }
}
