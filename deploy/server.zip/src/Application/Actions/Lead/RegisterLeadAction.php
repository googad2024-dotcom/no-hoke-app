<?php

declare(strict_types=1);

namespace App\Application\Actions\Lead;

use App\Application\Services\DiagnosisScorer;
use App\Application\Services\MailService;
use App\Models\DiagnosisSession;
use App\Models\Lead;
use App\Models\ResultAccessToken;
use Carbon\Carbon;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;

class RegisterLeadAction
{
    private LoggerInterface $logger;
    private MailService $mailService;
    private DiagnosisScorer $scorer;

    public function __construct(LoggerInterface $logger, MailService $mailService)
    {
        $this->logger = $logger;
        $this->mailService = $mailService;
        $this->scorer = new DiagnosisScorer();
    }

    public function __invoke(Request $request, Response $response): Response
    {
        try {
            $data = $request->getParsedBody();

            // バリデーション
            if (empty($data['session_id']) || empty($data['email'])) {
                $error = [
                    'success' => false,
                    'message' => 'Session ID and email are required'
                ];
                $response->getBody()->write(json_encode($error));
                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus(400);
            }

            // メールアドレス形式チェック
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $error = [
                    'success' => false,
                    'message' => 'Invalid email format'
                ];
                $response->getBody()->write(json_encode($error));
                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus(400);
            }

            // セッションを取得
            $session = DiagnosisSession::where('session_id', $data['session_id'])->first();

            if (!$session) {
                $error = ['success' => false, 'message' => 'Session not found'];
                $response->getBody()->write(json_encode($error));
                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus(404);
            }

            // リードを作成（既存の場合は更新）
            $lead = Lead::updateOrCreate(
                ['diagnosis_session_id' => $session->id],
                ['email' => $data['email']]
            );

            // アクセストークンを生成
            $token = ResultAccessToken::generateToken();
            $expiresAt = Carbon::now()->addDays(7); // 7日間有効

            ResultAccessToken::create([
                'lead_id' => $lead->id,
                'token' => $token,
                'expires_at' => $expiresAt,
            ]);

            $this->logger->info('Lead registered', [
                'lead_id' => $lead->id,
                'email' => $data['email']
            ]);

            // 結果閲覧用URL（フロントエンドのフル結果ページを指す）
            $frontendUrl = $_ENV['FRONTEND_URL'] ?? $_ENV['APP_URL'] ?? '';
            // 静的エクスポート（動的セグメント不可）のためクエリ文字列でトークンを渡す
            $resultUrl = rtrim($frontendUrl, '/') . '/result/?token=' . $token;

            // 診断サマリー（メール本文の途中結果表示用）を算出
            $diagnosis = $this->scorer->calculate($session);

            // 結果閲覧用URLを含むHTMLメールを送信
            try {
                $this->mailService->sendResultEmail($data['email'], $resultUrl, $diagnosis);
            } catch (\Throwable $mailError) {
                $this->logger->error('Failed to send result email', [
                    'lead_id' => $lead->id,
                    'error'   => $mailError->getMessage(),
                ]);

                $error = [
                    'success' => false,
                    'message' => 'メール送信に失敗しました。時間をおいて再度お試しください。',
                ];
                $response->getBody()->write(json_encode($error));
                return $response
                    ->withHeader('Content-Type', 'application/json')
                    ->withStatus(500);
            }

            $result = [
                'success' => true,
                'lead_id' => $lead->id,
                'token' => $token,
                'result_url' => $resultUrl,
                'message' => 'Lead registered successfully',
            ];

            $response->getBody()->write(json_encode($result));
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(201);

        } catch (\Exception $e) {
            $this->logger->error('Failed to register lead', [
                'error' => $e->getMessage()
            ]);

            $error = [
                'success' => false,
                'message' => 'Failed to register lead',
            ];

            $response->getBody()->write(json_encode($error));
            return $response
                ->withHeader('Content-Type', 'application/json')
                ->withStatus(500);
        }
    }
}
