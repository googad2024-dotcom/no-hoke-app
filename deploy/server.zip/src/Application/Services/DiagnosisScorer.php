<?php

declare(strict_types=1);

namespace App\Application\Services;

use App\Models\DiagnosisSession;

class DiagnosisScorer
{
    public function calculate(DiagnosisSession $session): array
    {
        $income = (float) $session->monthly_income;
        $fixed  = (float) $session->monthly_fixed_cost;
        $cash   = (float) $session->savings;
        $ins    = (float) $session->monthly_insurance;

        $lifespan  = $fixed > 0 ? $cash / $fixed : 0;
        $fixedRate = $income > 0 ? $fixed / $income * 100 : 0;
        $insRate   = $income > 0 ? $ins   / $income * 100 : 0;
        $dispRate  = $income > 0 ? ($income - $fixed - $ins) / $income * 100 : 0;

        $L = $this->scoreLifespan($lifespan);
        $F = $this->scoreFixed($fixedRate);
        $I = $this->scoreIns($insRate);
        $D = $this->scoreDisp($dispRate);

        $score = max(0, 100 - $L['ded'] - $F['ded'] - $I['ded'] - $D['ded']);
        $grade = $this->grade($score);

        return [
            'score'         => $score,
            'grade'         => $grade['g'],
            'grade_message' => $grade['msg'],
            'breakdown'     => [
                [
                    'name'          => '流動性余命',
                    'description'   => '現預金 ÷ 月間固定費',
                    'max_deduction' => 40,
                    'deduction'     => $L['ded'],
                    'label'         => $L['label'],
                    'value'         => round($lifespan, 1),
                ],
                [
                    'name'          => '固定費率',
                    'description'   => '月間固定費 ÷ 手取り月収',
                    'max_deduction' => 25,
                    'deduction'     => $F['ded'],
                    'label'         => $F['label'],
                    'value'         => round($fixedRate, 1),
                ],
                [
                    'name'          => '保険料率',
                    'description'   => '月間保険料 ÷ 手取り月収',
                    'max_deduction' => 25,
                    'deduction'     => $I['ded'],
                    'label'         => $I['label'],
                    'value'         => round($insRate, 1),
                ],
                [
                    'name'          => '可処分所得率',
                    'description'   => '(手取り − 固定費 − 保険料) ÷ 手取り',
                    'max_deduction' => 10,
                    'deduction'     => $D['ded'],
                    'label'         => $D['label'],
                    'value'         => round($dispRate, 1),
                ],
            ],
        ];
    }

    // ─── 各指標スコア ────────────────────────────────────────

    private function scoreLifespan(float $m): array
    {
        if ($m >= 24) return ['ded' => 0,  'label' => round($m, 1) . 'ヶ月（24ヶ月以上）'];
        if ($m >= 12) return ['ded' => 10, 'label' => round($m, 1) . 'ヶ月（12〜23ヶ月）'];
        if ($m >= 6)  return ['ded' => 25, 'label' => round($m, 1) . 'ヶ月（6〜11ヶ月）'];
        return               ['ded' => 40, 'label' => round($m, 1) . 'ヶ月（0〜5ヶ月）'];
    }

    private function scoreFixed(float $r): array
    {
        if ($r <= 30) return ['ded' => 0,  'label' => round($r, 1) . '%（30%以下）'];
        if ($r <= 40) return ['ded' => 5,  'label' => round($r, 1) . '%（31〜40%）'];
        if ($r <= 50) return ['ded' => 15, 'label' => round($r, 1) . '%（41〜50%）'];
        return               ['ded' => 25, 'label' => round($r, 1) . '%（51%以上）'];
    }

    private function scoreIns(float $r): array
    {
        if ($r <= 5)  return ['ded' => 0,  'label' => round($r, 1) . '%（5%以下）'];
        if ($r <= 10) return ['ded' => 10, 'label' => round($r, 1) . '%（6〜10%）'];
        if ($r <= 15) return ['ded' => 20, 'label' => round($r, 1) . '%（11〜15%）'];
        return               ['ded' => 25, 'label' => round($r, 1) . '%（16%以上）'];
    }

    private function scoreDisp(float $r): array
    {
        if ($r >= 50) return ['ded' => 0,  'label' => round($r, 1) . '%（50%以上）'];
        if ($r >= 40) return ['ded' => 3,  'label' => round($r, 1) . '%（40〜49%）'];
        if ($r >= 30) return ['ded' => 6,  'label' => round($r, 1) . '%（30〜39%）'];
        return               ['ded' => 10, 'label' => round($r, 1) . '%（29%以下）'];
    }

    private function grade(int $s): array
    {
        if ($s >= 80) return ['g' => 'S', 'msg' => 'この調子で将来に向けて準備ができています。流動性は非常に高く理想的な状態です。'];
        if ($s >= 60) return ['g' => 'A', 'msg' => '良い状態です。流動性余命と固定費を意識してさらに改善を目指しましょう。'];
        if ($s >= 40) return ['g' => 'B', 'msg' => '平均的な状態です。現預金の厚みや固定費・保険料の重さを点検しましょう。'];
        return               ['g' => 'C', 'msg' => '改善することで将来の安心につながります。早めの見直しを推奨します。'];
    }
}
