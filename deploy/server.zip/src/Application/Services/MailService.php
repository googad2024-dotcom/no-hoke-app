<?php

declare(strict_types=1);

namespace App\Application\Services;

use PHPMailer\PHPMailer\Exception as PHPMailerException;
use PHPMailer\PHPMailer\PHPMailer;
use Psr\Log\LoggerInterface;
use RuntimeException;

/**
 * SMTP（PHPMailer）によるメール送信サービス。
 *
 * SMTP接続情報は .env から取得する:
 *   MAIL_HOST / MAIL_PORT / MAIL_USERNAME / MAIL_PASSWORD
 *   MAIL_ENCRYPTION (tls|ssl|'') / MAIL_FROM_ADDRESS / MAIL_FROM_NAME
 */
class MailService
{
    private const BRAND_NAME = 'NoHoKe';

    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * 診断結果案内メールを送信する。
     *
     * @param string $toEmail   宛先メールアドレス
     * @param string $resultUrl 診断結果フルページのURL
     * @param array  $diagnosis DiagnosisScorer::calculate() の戻り値（score / grade を使用）
     *
     * @throws RuntimeException SMTP未設定・送信失敗時
     */
    public function sendResultEmail(string $toEmail, string $resultUrl, array $diagnosis): void
    {
        $host = $_ENV['MAIL_HOST'] ?? '';
        if ($host === '') {
            throw new RuntimeException('MAIL_HOST is not configured (.env). メール送信設定が未設定です。');
        }

        $score = (int) ($diagnosis['score'] ?? 0);
        $grade = (string) ($diagnosis['grade'] ?? '-');

        $mailer = new PHPMailer(true);

        try {
            $mailer->isSMTP();
            $mailer->Host       = $host;
            $mailer->Port       = (int) ($_ENV['MAIL_PORT'] ?? 587);
            $mailer->CharSet    = PHPMailer::CHARSET_UTF8;

            $username = $_ENV['MAIL_USERNAME'] ?? '';
            $password = $_ENV['MAIL_PASSWORD'] ?? '';
            if ($username !== '') {
                $mailer->SMTPAuth = true;
                $mailer->Username = $username;
                $mailer->Password = $password;
            }

            $encryption = $_ENV['MAIL_ENCRYPTION'] ?? 'tls';
            if ($encryption === 'tls') {
                $mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($encryption === 'ssl') {
                $mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mailer->SMTPSecure = '';
                $mailer->SMTPAutoTLS = false;
            }

            $fromAddress = $_ENV['MAIL_FROM_ADDRESS'] ?? 'no-reply@example.com';
            $fromName    = $_ENV['MAIL_FROM_NAME'] ?? self::BRAND_NAME;
            $mailer->setFrom($fromAddress, $fromName);
            $mailer->addAddress($toEmail);

            $mailer->isHTML(true);
            $mailer->Subject = '【' . self::BRAND_NAME . '】資産形成診断結果のご案内';
            $mailer->Body    = $this->renderHtml($resultUrl, $score, $grade);
            $mailer->AltBody = $this->renderText($resultUrl, $score, $grade);

            $mailer->send();

            $this->logger->info('Result email sent', [
                'to'    => $toEmail,
                'score' => $score,
                'grade' => $grade,
            ]);
        } catch (PHPMailerException $e) {
            $this->logger->error('Failed to send result email', [
                'to'    => $toEmail,
                'error' => $mailer->ErrorInfo ?: $e->getMessage(),
            ]);
            throw new RuntimeException('メール送信に失敗しました', 0, $e);
        }
    }

    /**
     * HTMLメール本文をレンダリングする。
     */
    private function renderHtml(string $resultUrl, int $score, string $grade): string
    {
        $brandName  = self::BRAND_NAME;
        $gradeLabel = $this->gradeLabel($grade);

        ob_start();
        require __DIR__ . '/templates/result_email.php';
        return (string) ob_get_clean();
    }

    /**
     * プレーンテキスト代替本文。
     */
    private function renderText(string $resultUrl, int $score, string $grade): string
    {
        return implode("\n", [
            self::BRAND_NAME . ' 資産形成診断結果のご案内',
            '',
            'この度は資産形成診断をご利用いただきありがとうございます。',
            'お客様の診断結果がご確認いただけるようになりました。',
            '',
            '診断結果を見る:',
            $resultUrl,
            '',
            '※上記URLは本メール送信後7日間有効です。',
            '',
            '【診断内容サマリー（途中結果）】',
            '総合スコア: ' . $score . '/100',
            '総合ランク: ' . $grade . ' ランク',
            'ライフプラン充実度: ' . $this->gradeLabel($grade),
            '',
            '本診断結果ページはお客様だけがアクセスできるプライベートURLです。',
            '第三者に共有しないようご注意ください。',
        ]);
    }

    /**
     * ランク（A/B/C/D）→ ライフプラン充実度の文言。
     */
    private function gradeLabel(string $grade): string
    {
        return match (strtoupper($grade)) {
            'A'     => '良好',
            'B'     => 'やや良好',
            'C'     => '普通',
            'D'     => '要改善',
            default => '-',
        };
    }
}
